namespace listy
{

    public partial class Form1 : Form
    {
        private Lista lista = new Lista();
        public Form1()
        {
            InitializeComponent();
        }
        

        public class Node
        {
            public int Data { get; set; }
            public Node Next { get; set; }

            public Node(int data)
            {
                Data = data;
                Next = null;
            }
        }

        public class Lista
        {
            private Node head;

            public Lista()
            {
                head = null;
            }

            public void Dodajp(int data)
            {
                Node newNode = new Node(data);
                newNode.Next = head;
                head = newNode;
                
            }

            public void Dodajk(int data)
            {
                Node newNode = new Node(data);

                if (head == null)
                {
                    head = newNode;
                }
                else
                {

                    Node el = head;
                    while (el.Next != null)
                    {
                        el = el.Next;
                    }
                    el.Next = newNode;
                }
            }

            public string naTekst()
            {
                Node el = head;
                string result = " ";
                while (el != null)
                {
                    result += el.Data + " \n ";
                    el = el.Next;
                }
                result += "null";
                return result;
            }
            public void Usunp()
            {
                if (head != null)
                {
                    head = head.Next;
                }
            }

            public void Usunk()
            {
                if (head == null) return;

                if (head.Next == null)
                {
                    head = null;
                }
                else
                {
                    Node el = head;
                    while (el.Next.Next != null)
                    {
                        el = el.Next;
                    }
                    el.Next = null;
                }
            }

            
            public int[] Tablica()
            {
                int count = 0;
                Node el = head;
                while (el != null)
                {
                    count++;
                    el = el.Next;
                }
                int[] result = new int[count];

                el = head;
                for (int i = 0; i < count; i++)
                {
                    result[i] = el.Data;
                    el = el.Next;
                }

                return result;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int liczba))
            {
                lista.Dodajp(liczba);
                textBox1.Clear();

            }
            else
            {
                MessageBox.Show("Dodaj liczbe", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            listBox1.Items.Clear();
            int[] tab = lista.Tablica();

            foreach (int el in tab)
            {
                listBox1.Items.Add(el);
                
            }
        }



        private void button2_Click_1(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text, out int liczba))
            {
                lista.Dodajk(liczba);
                textBox2.Clear();

            }
            else
            {
                MessageBox.Show("Dodaj liczbe", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            listBox1.Items.Clear();
            int[] tab = lista.Tablica();

            foreach (int el in tab)
            {
                listBox1.Items.Add(el);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lista.Usunp();
            

            listBox1.Items.Clear();
            int[] tab = lista.Tablica();

            foreach (int liczba in tab)
            {
                listBox1.Items.Add(liczba);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            lista.Usunk();
            

            listBox1.Items.Clear();
            int[] tab = lista.Tablica();

            foreach (int liczba in tab)
            {
                listBox1.Items.Add(liczba);
            }
        }



        private void button5_Click(object sender, EventArgs e)
        {
            textBox3.Text = lista.naTekst().Replace("null","");
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            int[] tab = lista.Tablica();

            foreach (int liczba in tab)
            {
                listBox2.Items.Add(liczba);
            }
        }
        

    }
}
