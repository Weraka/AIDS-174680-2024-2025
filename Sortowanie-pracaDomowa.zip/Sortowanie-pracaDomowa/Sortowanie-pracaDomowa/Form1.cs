namespace Sortowanie_pracaDomowa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] tab;
        int i = 0;

        //BubbleSort

        static void BubbleSort(int[] tab)
        {
            int n = tab.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (tab[j + 1] < tab[j])
                    {
                        var pom = tab[j + 1];
                        tab[j + 1] = tab[j];
                        tab[j] = pom;
                    }
                }
            }
        }

        //InsertionSort

        static void InsertionSort(int[] tab)
        {
            for (int i = 1; i < tab.Length; i++)
            {
                int klucz = tab[i];
                int j = i - 1;
                while (j >= 0 && tab[j] > klucz)
                {
                    tab[j + 1] = tab[j];
                    j--;
                }
                tab[j + 1] = klucz;
            }
        }

        //MergeSort 

        static void MergeSort(int[] tab)
        {
            if (tab.Length <= 1)
            {
                return;
            }
            int srodek = tab.Length / 2;
            int[] lewatab = new int[srodek];
            int[] prawatab = new int[tab.Length - srodek];

            for (int i = 0; i < srodek; i++)
            {
                lewatab[i] = tab[i];
            }
            for (int i = srodek; i < tab.Length; i++)
            {
                prawatab[i - srodek] = tab[i];
            }
            MergeSort(lewatab);
            MergeSort(prawatab);
            Merge(tab, lewatab, prawatab);

        }
        static void Merge(int[] tab, int[] lewatab, int[] prawatab)
        {
            int idtab = 0;
            int idlewej = 0;
            int idprawej = 0;

            while (idlewej < lewatab.Length && idprawej < prawatab.Length)
            {
                if (lewatab[idlewej] < prawatab[idprawej])
                {
                    tab[idtab] = lewatab[idlewej];
                    idlewej++;
                    idtab++;
                }
                else
                {
                    tab[idtab] = prawatab[idprawej];
                    idprawej++;
                    idtab++;
                }
            }
            while (idlewej < lewatab.Length)
            {
                tab[idtab] = lewatab[idlewej];
                idlewej++;
                idtab++;
            }
            while (idprawej < prawatab.Length)
            {
                tab[idtab] = prawatab[idprawej];
                idprawej++;
                idtab++;
            }

        }

        //CountingSort

        static void CountingSort(int[] tab)
        {
            int max = tab.Max();
            int min = tab.Min();
            int[] nowatab = new int[max - min + 1];

            for (int i = 0; i < tab.Length; i++)
            {
                nowatab[tab[i] - min]++;
            }
            int j = 0;
            for (int i = 0; i < nowatab.Length; i++)
            {
                while (nowatab[i] > 0)
                {
                    tab[j] = i + min;
                    j++;
                    nowatab[i]--;
                }
            }

        }
        //QuickSort
        static void QuickSort(int[] array, int dolny, int gorna)
        {
            if (dolny < gorna)
            {
                int pivotIndex = podzieltab(array, dolny, gorna);
                QuickSort(array, dolny, pivotIndex - 1);
                QuickSort(array, pivotIndex + 1, gorna);
            }
        }

        static int podzieltab(int[] array, int dolny1, int gorny2)
        {
            int pivot = array[gorny2];
            int i = dolny1 - 1;

            for (int j = dolny1; j < gorny2; j++)
            {
                if (array[j] <= pivot)
                {
                    i++;
                    Zamien(array, i, j);
                }
            }
            Zamien(array, i + 1, gorny2);
            return i + 1;
        }
        static void Zamien(int[] array, int i, int j)
        {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tab = new int[int.Parse(textBox2.Text)];
            textBox2.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            tab[i] = int.Parse(textBox1.Text);
            textBox1.Clear();
            i++;
            label1.Text = string.Join(",", tab);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BubbleSort(tab);
            label5.Text = string.Join(",", tab);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MergeSort(tab);
            label5.Text = string.Join(",", tab);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InsertionSort(tab);
            label5.Text = string.Join(",", tab);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CountingSort(tab);
            label5.Text = string.Join(",", tab);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            QuickSort(tab,0,tab.Length-1);
            label5.Text = string.Join(",", tab);
        }
    }
}
